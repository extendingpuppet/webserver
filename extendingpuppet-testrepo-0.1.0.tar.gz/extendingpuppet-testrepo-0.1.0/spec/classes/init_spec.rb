require 'spec_helper'
describe 'testrepo' do
  context 'with default values for all parameters' do
    it { should contain_class('testrepo') }
  end
end
